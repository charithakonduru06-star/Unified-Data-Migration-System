<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <title>Data Migration</title>
</head>
<body>
<div class="container-fluid">
    <h1 align="center">Data Migration Tool</h1>
    <div class="row">
        <div class="col-md-4 col-lg-4"></div>
        <div class="col-md-4 col-lg-4">
            <form align="center" method="post">
                <input type="radio" name="db" value="oracle" required /> Oracle  
                <input type="radio" name="db" value="mysql" required /> MySQL <br><br>
                <input type="text" name="loginID" placeholder="Database Login ID" class="form-control" required /><br>
                <input type="password" name="loginpwd" placeholder="Database Login Password" class="form-control" required /><br>
                <input type="submit" value="Submit" name="submit" class="btn btn-primary" />
                <input type="button" value="Cancel" class="btn btn-secondary" />  
            </form>
            <%
                if(request.getParameter("submit")!=null){
                    session.setAttribute("selectdb",request.getParameter("db"));
                    session.setAttribute("logindbid",request.getParameter("loginID"));
                    session.setAttribute("logindbpwd",request.getParameter("loginpwd"));
                    response.sendRedirect("home.jsp");
                }
            %>
        </div>
        <div class="col-md-4 col-lg-4"></div>
    </div>
</div> 
</body>
</html>