<%@page import="java.sql.*" language="java" contentType="text/html" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <title>Data Migration</title>
</head>
<body>
<div class="container-fluid">
    <h1 align="center">Data Migration Tool</h1>
    <div class="row">
        <div class="col-md-3 col-lg-3"></div>
        <div class="col-md-6 col-lg-6">
<%
    String selectdb = (String)session.getAttribute("selectdb");
    String username = (String)session.getAttribute("logindbid");
    String password = (String)session.getAttribute("logindbpwd");
    /*Oracle Connection*/
    if(selectdb.equals("oracle")){
        try{
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection conn = null;
            conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521",username,password);
            if(conn==null){
                out.print("Connection Failed");
            }
            out.print("<h1 align='center'>Oracle Database Connected</h1>");
            out.print("<p align='right'><a href='logout.jsp' class='btn btn-warning'>Logout</a></p><br>");
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("select * from dba_users");
            out.print("<h3>List of Database Users:</h3><ul>");
            while(rs.next()){ %>
                <li><a href='showTables.jsp?dbname=<%= rs.getString(1) %>'><%= rs.getString(1) %></a></li>
        <%  }
            out.print("</ul>");
        }catch(Exception e){
            out.print("Error: "+e.toString());
        }
    }
    /*MySQL Connection*/
    else if(selectdb.equals("mysql")){
        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = null;
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/",username,password);
            if(conn==null){
                out.print("Connection Failed");
            }
            out.print("<h1 align='center'>MySQL Database Connected</h1>");
            out.print("<p align='right'><a href='logout.jsp' class='btn btn-warning'>Logout</a></p><br>");
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("show databases");
            out.print("<h3>List of Databases:</h3><ul>");
            while(rs.next()){ %>
                <li><a href='showTables.jsp?dbname=<%= rs.getString(1) %>'><%= rs.getString(1) %></a></li>
        <%  }
            out.print("</ul>");
        }catch(Exception e){
            out.print("Error: "+e.toString());
        }
    }
%>
        </div>
        <div class="col-md-3 col-lg-3"></div>
    </div>
</div>
</body>
</html>