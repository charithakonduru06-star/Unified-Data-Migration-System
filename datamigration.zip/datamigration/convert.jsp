<%@page import="java.sql.*" language="java" contentType="text/html" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <title>Data Migration</title>
</head>
<body>
<div class="container-fluid">
    <h1 align="center">Data Migration Tool</h1>
    <div class="row">
        <div class="col-md-3 col-lg-3"></div>
        <div class="col-md-6 col-lg-6">
<%
    String selectdb = (String)session.getAttribute("selectdb");
    String username = (String)session.getAttribute("logindbid");
    String password = (String)session.getAttribute("logindbpwd");
    String db = (String)session.getAttribute("dbname");
    /*Oracle Connection*/
    if(selectdb.equals("oracle")){
        try{ 
            String tablename = request.getParameter("tablename");
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection conn = null;
            conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe",username,password);
            if(conn==null){
                out.print("Connection Failed");
            }
            out.print("<h1 align='center'>Oracle Database Connected</h1>");
            out.print("<p align='right'><a href='logout.jsp' class='btn btn-warning'>Logout</a></p><br>");
            Statement stmt = conn.createStatement();
            //Description of Table
            ResultSet rs = stmt.executeQuery("select * from "+tablename);
            ResultSetMetaData rsmd = rs.getMetaData();
            int colcount = rsmd.getColumnCount();
            out.print("<table class='table table-bordered'><tr><th>Field</th><th>Type</th><th>Length</th></tr>");
            String convertQuery = "create table "+tablename+"(";
            for(int i=1;i<=colcount;i++){
                out.print("<tr><td>"+rsmd.getColumnName(i)+"</td><td>"+rsmd.getColumnTypeName(i)+"</td><td>"+rsmd.getPrecision(i)+"</td></tr>");
                if(rsmd.getColumnTypeName(i).equals("NUMBER")){
                    convertQuery = convertQuery + rsmd.getColumnName(i)+" int("+rsmd.getPrecision(i)+"),";
                }else if(rsmd.getColumnTypeName(i).equals("VARCHAR2")){
                    convertQuery = convertQuery + rsmd.getColumnName(i)+" varchar("+rsmd.getPrecision(i)+"),";
                }
            }
            convertQuery = convertQuery.substring(0,convertQuery.length()-1)+")";
            out.print("</table>");
            //Extract records
            int i = 0;
            rs = stmt.executeQuery("select count(*) from "+tablename);
            rs.next();
            String InsertQueries[] = new String[rs.getInt(1)];
            ResultSet rs2 = stmt.executeQuery("select * from "+tablename);
            while(rs2.next()){
                String iq = "insert into "+tablename+" values(";
                for(int j=1;j<=colcount;j++){
                    if(rsmd.getColumnTypeName(j).equals("NUMBER")){
                        iq += rs2.getInt(j)+",";
                    }else if(rsmd.getColumnTypeName(j).equals("VARCHAR2")){
                        iq += "'"+rs2.getString(j)+"',";
                    }
                }
                iq = iq.substring(0,iq.length()-1)+")";
                InsertQueries[i++] = iq;
                out.print(iq);
            }
        %>
        <form method="post">
            <input type="submit" name="convertTable" value="Convert Table" />
        </form>
        <%
            if(request.getParameter("convertTable")!=null){
                //Oracle Connection for Converting
                Class.forName("com.mysql.jdbc.Driver");
                Connection mconn = null;
                mconn = DriverManager.getConnection("jdbc:mysql://localhost:3306/converttables","root","admin");
                if(mconn==null){
                    out.print("Connection Failed");
                }
                Statement mstmt = mconn.createStatement();
                mstmt.execute(convertQuery);
                for(i=0;i < InsertQueries.length;i++){
                    mstmt.executeUpdate(InsertQueries[i]);
                }
                response.sendRedirect("showTables.jsp?dbname=xe");
            }
        }catch(Exception e){
            out.print("Error: "+e.toString());
        }
    }

    /*MySQL Connection*/
    if(selectdb.equals("mysql")){
        try{ 
            String tablename = request.getParameter("tablename");
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = null;
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/converttables",username,password);
            if(conn==null){
                out.print("Connection Failed");
            }
            out.print("<h1 align='center'>MySQL Database Connected</h1>");
            out.print("<p align='right'><a href='logout.jsp' class='btn btn-warning'>Logout</a></p><br>");
            Statement stmt = conn.createStatement();
            //Description of Table
            ResultSet rs = stmt.executeQuery("select * from "+tablename);
            ResultSetMetaData rsmd = rs.getMetaData();
            int colcount = rsmd.getColumnCount();
            out.print("<table class='table table-bordered'><tr><th>Field</th><th>Type</th><th>Length</th></tr>");
            String convertQuery = "create table "+tablename+"(";
            for(int i=1;i<=colcount;i++){
                out.print("<tr><td>"+rsmd.getColumnName(i)+"</td><td>"+rsmd.getColumnTypeName(i)+"</td><td>"+rsmd.getPrecision(i)+"</td></tr>");
                if(rsmd.getColumnTypeName(i).equals("INT")){
                    convertQuery = convertQuery + rsmd.getColumnName(i)+" number("+rsmd.getPrecision(i)+"),";
                }else if(rsmd.getColumnTypeName(i).equals("VARCHAR")){
                    convertQuery = convertQuery + rsmd.getColumnName(i)+" varchar2("+rsmd.getPrecision(i)+"),";
                }
            }
            convertQuery = convertQuery.substring(0,convertQuery.length()-1)+")";
            out.print("</table>");
            //Extract records
            int i = 0;
            rs = stmt.executeQuery("select count(*) from "+tablename);
            rs.next();
            String InsertQueries[] = new String[rs.getInt(1)];
            ResultSet rs2 = stmt.executeQuery("select * from "+tablename);
            while(rs2.next()){
                String iq = "insert into "+tablename+" values(";
                for(int j=1;j<=colcount;j++){
                    if(rsmd.getColumnTypeName(j).equals("INT")){
                        iq += rs2.getInt(j)+",";
                    }else if(rsmd.getColumnTypeName(j).equals("VARCHAR")){
                        iq += "'"+rs2.getString(j)+"',";
                    }
                }
                iq = iq.substring(0,iq.length()-1)+")";
                InsertQueries[i++] = iq;
                out.print(iq);
            }
        %>
        <form method="post">
            <input type="submit" name="convertTable" value="Convert Table" />
        </form>
        <%
            if(request.getParameter("convertTable")!=null){
                //Oracle Connection for Converting
                Class.forName("oracle.jdbc.driver.OracleDriver");
                Connection mconn = null;
                mconn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/xe","SYSTEM","admin");
                if(mconn==null){
                    out.print("Connection Failed");
                }
                Statement mstmt = mconn.createStatement();
                mstmt.execute(convertQuery);
                for(i=0;i < InsertQueries.length;i++){
                    mstmt.executeUpdate(InsertQueries[i]);
                }
                response.sendRedirect("showTables.jsp?dbname=xe");
            }
        }catch(Exception e){
            out.print("Error: "+e.toString());
        }
    }

%>
        </div>
        <div class="col-md-3 col-lg-3"></div>
    </div>
</div>
</body>
</html>